# my_purchase
Provide advice for a future large purchase (House, Car, Holiday) 
based on simple financial situation (monthly income, expenses and actual savings)
